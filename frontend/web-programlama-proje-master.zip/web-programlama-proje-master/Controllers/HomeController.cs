using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using UniClubSistemi.Models;

namespace UniClubSistemi.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        // 1. Ana Sayfa: Herkesin g�rebildi�i ilk kar��lama ekran�
        public IActionResult Index()
        {
            return View();
        }

        // 2. Etkinlik Takvimi: Payla��lan t�m etkinliklerin listelendi�i sayfa
        public IActionResult Etkinlikler()
        {
            return View();
        }

        // 3. Kul�pler Rehberi: �niversite b�nyesindeki kul�plerin tan�t�m�
        public IActionResult Kul�pler()
        {
            return View();
        }

        // 4. Yetkilendirme - Giri�: Kul�p ba�kanlar�n�n y�netim paneline giri�i
        public IActionResult Giri�()
        {
            return View();
        }

        // 5. Yetkilendirme - Kay�t: Yeni kul�plerin sisteme dahil olma talebi
        public IActionResult Kay�tOl()
        {
            return View();
        }

        // 6. Etkinlik Y�netimi: Sadece giri� yapm�� yetkililerin g�rece�i form
        // (�u an tasar�m a�amas�nda oldu�u i�in kap�s� herkese a��k)
        public IActionResult EtkinlikEkle()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}